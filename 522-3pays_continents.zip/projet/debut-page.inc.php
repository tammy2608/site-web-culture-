<?php
require_once("connexion_base.php"); ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3pays_3continents</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link rel="stylesheet" href="css/connexion.css">
    <link rel="stylesheet" href="css/accueil.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>
<body id ="top">
    <header>
        <nav>
            <div class="nav-wrapper" >
                <ul>
                    <li><a href="accueil.php">Accueil</a></li>
                    <?php
                    $requete_pays = "SELECT * FROM projet_pays";
                    $reponse_pays = $pdo->prepare($requete_pays);
                    $reponse_pays->execute();
                    $pays = $reponse_pays->fetchAll();

                    $nb_pays = count($pays);

                    $requete_ville = "SELECT * FROM projet_ville";
                    $reponse_ville = $pdo->prepare($requete_ville);
                    $reponse_ville->execute();
                    $ville = $reponse_ville->fetchAll();

                    $nb_ville = count($ville);

                    for ($i = 0; $i < $nb_pays; $i++) {
                        echo "<li class='deroulant'><a href='pays.php?pays=".$pays[$i]['id']."'>".$pays[$i]['nom']."</a></li>";
                    }
                    ?>

                    <li><a href="connexion.php">Connexion</a></li>

    
                </ul>
            </div>
            
        </nav>
            </header>
