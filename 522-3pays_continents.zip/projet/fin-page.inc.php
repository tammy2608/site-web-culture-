<footer>
        <div>
            <p>&copy; 2025 3pays_3continents. Tous sont à découvrir.</p>
            <p>Partez à l'aventure avec nous ! Découvrez des destinations exotiques, des histoires inspirantes et des expériences uniques à travers le Vietnam, la France et Madagascar.</p>
            <a href="#top" class="scroll-to-top">&#8593;</a> 
        </div>
</footer>
</body>  
</html>