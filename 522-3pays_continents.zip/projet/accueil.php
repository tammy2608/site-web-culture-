<?php
require_once("connexion_base.php"); 
include "debut-page.inc.php"; // Inclure l'en-tête
?>
<h1 class= t >Trois Destinations, Mille Émotions</h1>
      <div class="row center">
        <h6">Laissez-vous emporter par la richesse culturelle du Vietnam, l’élégance intemporelle de la France, et la nature sauvage de Madagascar. Que vous rêviez de paysages à couper le souffle, d’expériences authentiques ou d’aventures inoubliables, nous vous guidons à travers des itinéraires uniques et des conseils personnalisés pour faire de chaque voyage une histoire à part entière.</h6>
      </div>

<?php
// Récupérer tous les pays
$requete_pays = "SELECT * FROM projet_pays";
$reponse_pays = $pdo->prepare($requete_pays);
$reponse_pays->execute();
$pays = $reponse_pays->fetchAll(); // Récupère tous les pays
?>
<?php

$images = [];

for ($i = 1; $i <= 16; $i++) {
    $images[] = "/cswd/projet/photos/photos-accueil/pays$i.jpg";
}
echo '<div class="carousel">';

// Boucle pour afficher les images dans le carousel
foreach ($images as $image) {
    echo '<a class="carousel-item" href="#!">';
    echo '<img src="' . $image . '" alt="image">';
    echo '</a>';
}

// Fin du carousel
echo '</div>';
?>

<?php
echo '<div class="row">';
foreach ($pays as $pays_info) {
    echo '<div class="col s12 m4">'; 
    echo '  <div class="center promo">';
    echo '    <p style="font-size: 30px; font-weight: bold;">' . $pays_info['nom'] . '</p>'; 

    $capital = $pays_info['capital']; 
    echo '    <p class="light center"><strong>Capitale: ' . $capital . '</strong></p>'; 
    echo '    <p>' . $pays_info['description'] . '</p>';
    echo '  </div>';
    echo '</div>';
}

echo '</div>';
?>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.carousel');
    var instances = M.Carousel.init(elems, {
      fullWidth: true,
      indicators: true
    });

    // Fonction pour ajuster la taille de l'image centrale
    function adjustImageSize() {
      const carouselItems = document.querySelectorAll('.carousel-item');
      const middleIndex = Math.floor(carouselItems.length / 2); // Trouver l'élément central

      carouselItems.forEach((item, index) => {
        const image = item.querySelector('img');
        
        // Réinitialiser toutes les images à la taille normale
        image.classList.remove('center-image');
        
        // Appliquer une taille différente à l'image au centre
        if (index === middleIndex) {
          image.classList.add('center-image'); // Appliquer un effet sur l'image centrale
        }
      });
    }

    // Appliquer les ajustements au début
    adjustImageSize();

    // Suivre les changements du carrousel
    elems[0].addEventListener('scroll', adjustImageSize);
  });
</script>
<style>
    /* Taille par défaut des images */
    .carousel-image {
        width: 100%; /* Largeur maximale pour remplir l'écran */
        height: 100vh; /* Hauteur de l'image égale à celle de l'élément */
        object-fit: cover; /* Garder les proportions de l'image, en rognant si nécessaire */
        
    }


</style>
<?php
include "fin-page.inc.php"; // Inclure le pied de page
?>