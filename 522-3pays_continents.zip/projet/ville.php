<?php
session_start();
$id_utilisateur= $_SESSION['id_utilisateur'];
$nom_utilisateur = $_SESSION['pseudo'];
require_once("connexion_base.php");
include "debut-page.inc.php"; 

$id_ville = $_GET['id'];

$requete_ville = "SELECT * FROM `projet_ville` WHERE `id` = ?";
$reponse_ville = $pdo->prepare($requete_ville);
$reponse_ville->execute(array($id_ville));
$ville = $reponse_ville->fetch(); 

$requete_pays = "SELECT * FROM `projet_pays` WHERE `id` = ?";
$reponse_pays = $pdo->prepare($requete_pays);
$reponse_pays->execute(array($ville['id_projet_pays']));
$pays = $reponse_pays->fetch(); 

$requete_evenement = "SELECT * FROM `projet_evenement` WHERE `id_projet_ville` = ?";
$reponse_evenement = $pdo->prepare($requete_evenement);
$reponse_evenement->execute(array($id_ville));
$evenements = $reponse_evenement->fetchAll();

$requete_recette = "SELECT * FROM `projet_recettes` WHERE `id_projet_ville` = ?";
$reponse_recette = $pdo->prepare($requete_recette);
$reponse_recette->execute(array($id_ville));
$recettes = $reponse_recette->fetchAll();


$requete_visite = "SELECT * FROM `projet_visite` WHERE `id_projet_ville` = ?";
$reponse_visite = $pdo->prepare($requete_visite);
$reponse_visite->execute(array($id_ville));
$visites = $reponse_visite->fetchAll();

?>

<h4 class= titre>Découvrir <?php echo $ville['nom'] ?></h4>
<div class="carousel">
<?php
$chemin_images = "photos/photos-ville/";
$nb_max_images = 10; 
for ($i = 1; $i <= $nb_max_images; $i++) {
    $chemin_image = $chemin_images . "ville-" . $id_ville . "-" . $i . ".jpeg";
    if (file_exists($chemin_image)) {
        echo '<a class="carousel-item"><img src="' . $chemin_image . '" alt="Image de la ville" height = "300" width= "500"></a>';
    }
}
?>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.carousel');
    var instances = M.Carousel.init(elems);
  });
</script>

<?php


if (isset($ville)) {
    echo '<div>';
    echo '<p style="color: #F26619; font-weight: bold; font-size: 20px;"><strong> Pays :</strong> ' . $pays['nom'] . '</p>';

    echo '<p  style="font-size: 20px; line-height: 1.6; margin-bottom: 20px;">Description :' . $ville['description'] . '</p>';
    echo '</div>';

    if (!empty($evenements)) {
        echo '<div class="bloc-ville">';

        echo '<h5 style="color: #F26619;">Événements</h5>';
        $chemin_images_even = "photos/photos-evenement/";
        $nb_max_photos = 10; 

        echo '<div class="evenements-gallery">';
        for ($i = 1; $i <= $nb_max_photos; $i++) {
        $chemin_image_evenement = $chemin_images_even . "even-" .$id_ville."-".$i . ".jpeg";
        if (file_exists($chemin_image_evenement)) {
            echo '<div class="evenement-item">';
            echo '<li><img src="' . $chemin_image_evenement . '" alt="Image de l\'événement" height="200" width="300"></li>';
            echo '</div>';
        }
        }
        echo '</div>';

        echo '<div>';
        echo '<ul>';
        foreach ($evenements as $evenement) {
            echo '<li  style="font-size: 20px; line-height: 1.6; margin-bottom: 20px;">' . $evenement['titre'] . ' :' . $evenement['description'] .'</li>';
            echo  '<li  style="font-size: 20px; line-height: 1.6; margin-bottom: 20px;"> la date de festival est : ' .$evenement['date'] .'</li>';
        echo '</ul>';
        echo '</div>';
    }
    
    echo '</div>';

    if (!empty($recettes)) {
        echo '<div class="bloc-recettes">';
        echo '<h5 style="color: #F26619;">Recettes Locales</h5>';

        $chemin_images_re = "photos/photos-recette/";
        $nb_max_pho = 10;
        
        echo '<div class="recettes-gallery">';

        for ($i = 1; $i <= $nb_max_pho; $i++) {
        $chemin_image_recette = $chemin_images_re . "re-" .$id_ville."-".$i . ".jpeg";
        if (file_exists($chemin_image_recette)) {
            echo '<div class="recette-item">';
            echo '<li><img src="' . $chemin_image_recette . '" alt="Image de la recette" height="200" width="300"></li>';
            echo '</div>';
        }
        }
        echo '</div>'; 
        echo '<ul>';
        foreach ($recettes as $recette) {
            echo '<li style="font-size: 20px; line-height: 1.6; margin-bottom: 20px;">' . $recette['titre'] . '</li>';
            echo '<li  style="font-size: 20px; line-height: 1.6; margin-bottom: 20px;"> Les ingrédients sont: ' . $recette['ingredients'] . '</li>';
            echo '<li  style="font-size: 20px; line-height: 1.6; margin-bottom: 20px;"> La préparation est :' . $recette['preparation'] . '</li>';
        }
        echo '</ul>';
        echo '</div>';
    }

    if (!empty($visites)) {
        echo '<div class="bloc-visites">';
        echo '<h5 style="color: #F26619;">Sites à Visiter</h5>';
        $chemin_images_vi = "photos/photos-visite/";
        $nb_max_photos = 10; 

        echo '<div class="visites-gallery">';

        for ($i = 1; $i <= $nb_max_photos; $i++) {
        $chemin_image_visite = $chemin_images_vi . "vi-" .$id_ville."-".$i . ".jpeg";
        if (file_exists($chemin_image_visite)) {
            echo '<div class="visite-item">';
            echo '<li><img src="' . $chemin_image_visite . '" alt="Image des visites" height="200" width="300"></li>';
            echo '</div>';
        }
        }
        echo '</div>'; 
        
        echo '<ul>';
        foreach ($visites as $visite) {
            echo '<li  style="font-size: 20px; line-height: 1.6; margin-bottom: 20px;">' . $visite['nom'] . ' : ' . $visite['description'] . '</li>';
        }
        echo '</ul>';
        
    }
    
}
}
echo '</div>';

?>
<br><br>

<div class="commentaire">
<h5 style="color: #F26619;">Laissez un commentaire</h5>
<form action="commentaire.php" method="post">
<fieldset>
    <label for="texte">Votre commentaire :</label><br>
    <input type="text" name="texte" id="com"><br><br>
  
    <label for="note">Votre note :</label>
    <select name="note" id="note" class="browser-default">
        <option value="" disabled selected>Choisir votre option</option>
        <option value="1">😡 Très mauvais</option>
        <option value="2">😕 Mauvais</option>
        <option value="3">😐 Moyen</option>
        <option value="4">🙂 Bien</option>
        <option value="5">😍 Excellent</option>
    </select><br><br>

    <!-- Vous pouvez ajouter les champs id_projet_ville et id_projet_utilisateur si nécessaire -->
    <input type="hidden" name="id_projet_ville" value="<?php echo $id_ville; ?>"> <!-- Valeur dynamique pour id_projet_ville -->
    <input type="hidden" name="id_projet_utilisateur" value="<?php echo $id_utilisateur; ?>"> <!-- Valeur dynamique pour id_projet_utilisateur -->


    <input type="submit" value="Envoyer">
</fieldset>

</div>
</form>

<?php
    $requete = "SELECT * FROM projet_commentaire where id_projet_ville = ? and validation=1";
    $reponse = $pdo->prepare($requete);
    $reponse->execute(array($id_ville));

    // récupérer tous les enregistrements dans un tableau
    $enregistrements = $reponse->fetchAll();

    // connaitre le nombre d'enregistrements
    $nb_enregistrements = count($enregistrements);

     //print_r($enregistrements);
    
    /// parcourir le tableau des enregistrements
    for ($i=0; $i< $nb_enregistrements; $i++)
    {
        echo "<table>";
        echo "<th>Nom</th>";
        echo "<th>Commentaire</th>";
        echo "<th>Note</th>";

            echo "<tr>";
                echo "<td>" .$nom_utilisateur."</td>";
                echo "<td>" .$enregistrements[$i]['texte'] ."</td>";
                echo "<td>" .$enregistrements[$i]['note'] ."</td>";
            echo "</tr>";
        echo "</table>";
    }
    
    ?>
<?php
include "fin-page.inc.php"; 
?>