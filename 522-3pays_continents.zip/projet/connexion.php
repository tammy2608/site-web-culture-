<?php session_start(); 
require_once("connexion_base.php");
include "debut-page.inc.php"; 
?>


<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">      
        <title>Connexion</title>
        <link rel="stylesheet" href="css/connexion.css">
    </head> 
    <body>

    
    <?php  
        if (isset($_SESSION['id_utilisateur']))
        { 
            echo "<h2 class = 'a'>Vous êtes connecté</h2>";
            echo "<p style='text-align: center;'><a href='deconnexion.php'>Se déconnecter</a></p>";

        }
        else 
        {
    ?>
        <h2>La connexion </h2> 
        <form action="verifier-connexion.php" method="post">
            <fieldset class=formulaire >
                <label for="texte"> Identifiant *:</label> 
                <br> 
                <input type ="text" name="pseudo" id ="pseudo"><br><br>

                <label for="password"> Mot de passe *:</label>
                <br>
                <input type ="password" name="motdepasse" id ="motdepasse"><br><br>

                <input type="submit" value = "Login">
                <p> Pas encore inscrit ?<a href ='inscription.php'> Inscription </a></p>
                
            </fieldset>
        </form>

        
    <?php 
        }

include "fin-page.inc.php";
