<?php require_once("connexion_base.php");
include "debut-page.inc.php"; ?>

    
<h2>Inscription d’un nouveau membre </h2>
    <form action="enregistrer_utilisateur.php" method="post">
        <fieldset class=formulaire>
            <label for="pseudo">Pseudo *:</label>
            <br>
            <input type="text" name="pseudo" id="pseudo"><br><br>

            <label for="motdepasse">Mot de passe *:</label>
            <br>
            <input type="password" name="motdepasse" id="motdepasse" minlength="8"><br><br>

            <label for="prenom">Prénom *:</label>
            <br>
            <input type="text" name="prenom" id="prenom"><br><br>

            <label for="nom">Nom *:</label>
            <br>
            <input type="text" name="nom" id="nom"><br><br>

            <label for="email">Email *:</label>
            <br>
            <input type="email" name="email" id="email"><br><br>
            
            
            <label>En soumettant ce formulaire, j’accepte que les informations saisies dans ce formulaire soient utilisées, exploitées, traitées, pour permettre de m’authentifier</label><br><br>
            
            <input type="submit" value="Valider mon inscription">
        </fieldset>
    </form>


<?php include "fin-page.inc.php"; ?>