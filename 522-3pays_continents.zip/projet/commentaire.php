<?php
require_once("connexion_base.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajout d'un commentaire</title>
</head>
<body>

<?php
// Initialisation du nombre de réponses
$nombreReponses = 0;

// Vérification si les données du formulaire sont présentes
if (!empty($_POST['texte']) && !empty($_POST['note']) && !empty($_POST['id_projet_ville']) && !empty($_POST['id_projet_utilisateur'])) {

    // Récupération des données envoyées par le formulaire
    $commentaire = $_POST['texte'];
    $note = $_POST['note'];
    $id_projet_ville = $_POST['id_projet_ville'];
    $id_projet_utilisateur = $_POST['id_projet_utilisateur'];

    // Affichage du commentaire pour vérification (optionnel)
    echo "Commentaire : " . $commentaire . "<br>";
    echo "Note : " . $note . "<br>";

    // Requête SQL d'insertion des données
    $requete_avis = "INSERT INTO projet_commentaire (id_projet_ville, id_projet_utilisateur, texte, note) VALUES (?, ?, ?, ?)";
    
    // Préparation de la requête
    $reponse = $pdo->prepare($requete_avis);

    // Exécution de la requête avec les valeurs récupérées
    $reponse->execute([$id_projet_ville, $id_projet_utilisateur, $commentaire, $note]);

    // Confirmation de l'insertion
    echo "Le commentaire et la note ont été ajoutés avec succès.";
} else {
    // Si une des données est manquante
    echo "Les données du formulaire sont manquantes.";
}
?>

<a href="ville.php?id=<?php echo $_POST['id_projet_ville']; ?>">Retourner à la page de la ville</a>



</body>
</html>



