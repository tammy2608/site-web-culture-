<?php
session_start(); 
require_once("connexion_base.php");
include "debut-page.inc.php"; 

if (isset($_GET['pays'])) {
    $id_pays = $_GET['pays'];

    $requete_pays = "SELECT * FROM `projet_pays` WHERE `id` = ?";
    $reponse_pays = $pdo->prepare($requete_pays);
    $reponse_pays->execute(array($id_pays));
    $pays = $reponse_pays->fetchAll(); 
    
    $requete_ville = "SELECT * FROM `projet_ville` WHERE `id_projet_pays` = ?";
    $reponse_ville = $pdo->prepare($requete_ville);
    $reponse_ville->execute(array($id_pays));
    $villes = $reponse_ville->fetchAll(); 
}
?>

<h4 class= titre>Venez explorer <?php echo htmlspecialchars($pays[0]['nom']); ?></h4>
<p>

<div id="map" style="width: 100%; height: 700px;"></div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

<?php 
if (isset($_SESSION['id_utilisateur'])) { ?>
    <script>
        function ajouterMarqueur(lat, lng, nom, id) {
            const marker = L.marker([lat, lng]).addTo(map)
            .bindPopup('<a href="ville.php?id=' + id + '">✈️ Allons découvrir ' + nom + '</a>');
        }
        <?php if (isset($pays[0])) {  ?>
            const map = L.map('map').setView([<?php echo $pays[0]['latitude_pays']; ?>, <?php echo $pays[0]['longitude_pays']; ?>], 6);
            const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            }).addTo(map);

            <?php foreach ($villes as $ville) { ?>
                ajouterMarqueur(<?php echo $ville['latitude_ville']; ?>, <?php echo $ville['longitude_ville']; ?>, "<?php echo $ville['nom']; ?>", "<?php echo $ville['id']; ?>");
            <?php } ?>
        <?php } else { ?>
            console.log("Aucun pays trouvé ou erreur dans la requête.");
        <?php } ?>
    </script>

 <?php 
    }
else { ?>
    <script>
        function ajouterMarqueur(lat, lng, nom, id) {
            const marker = L.marker([lat, lng]).addTo(map)
            .bindPopup('<a href="connexion.php">✈️ Allons découvrir ' + nom + '</a>');
        }
        <?php if (isset($pays[0])) {  ?>
            const map = L.map('map').setView([<?php echo $pays[0]['latitude_pays']; ?>, <?php echo $pays[0]['longitude_pays']; ?>], 6);
            const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            }).addTo(map);

            <?php foreach ($villes as $ville) { ?>
                ajouterMarqueur(<?php echo $ville['latitude_ville']; ?>, <?php echo $ville['longitude_ville']; ?>, "<?php echo $ville['nom']; ?>", "<?php echo $ville['id']; ?>");
            <?php } ?>
        <?php } else { ?>
            console.log("Aucun pays trouvé ou erreur dans la requête.");
        <?php } ?>
    </script>
<?php
    }

include "fin-page.inc.php"; 
?>
