<?php session_start();
require_once("connexion_base.php"); ?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">      
        <title>Vérification</title>
        <link rel="stylesheet" href="css/connexion.css">
    </head> 
    <body>
    <?php
        $nombreReponses = 0;
        if (!empty($_POST['pseudo']) && !empty($_POST['motdepasse']))
        {
            $pseudo = $_POST['pseudo'];
            $motdepasse = $_POST['motdepasse'];
    
            // exécuter une requete MySQL de type SELECT membre dans WHERE
            $requete = "SELECT * FROM projet_utilisateur WHERE pseudo = ?";
            // Si le membre existe le Where retourne 1 et le tableau des enregistrements contiendra un seul élément
            $reponse = $pdo->prepare($requete);
            $reponse->execute(array($pseudo));

            // récupérer tous les enregistrements dans un tableau
            $enregistrements = $reponse->fetchAll(); 
            // fetchAll() de l’objet $reponse retourne un tableau des enregistrements
            // fech()ne retournerait qu’un seul enregistrement (dans un tableau associatif)
            
            // connaitre le nombre d'enregistrements
            $nombreReponses = count($enregistrements);
   
        }

            // tester si un enregistrement existe 
            // (on suppose qu'un même pseudo n'existe qu'une seule fois !)
        if ($nombreReponses > 0)
        {
            // on vérifie si le mot de passe de la base de données au mot de passe du formulaire    
            $motdepasse_crypte = $enregistrements[0]['motdepasse'];
            if (password_verify($motdepasse, $motdepasse_crypte)) 
            {
                // pseudo et mot de passe correspondent
                echo "<h2>Bienvenue</h2>";
                echo "<a href='accueil.php'>Retour à l'accueil</a>";
                $_SESSION['pseudo'] = $enregistrements[0]['pseudo'];
                $_SESSION['id_utilisateur'] = $enregistrements[0]['id'];
            }
            else
            { 
                // pseudo existe mais mot de passe ne correspond pas
                echo "<h2>le mot de passe est incorrect</h2>";
                echo '<a href="connexion.php">retourner à la page de connexion</a>';
            }
        }
        else 
        {
            // le membre n'existe pas
            echo "<h2> Le membre n'existe pas </h2>";
            echo '<a href="connexion.php">retourner à la page de connexion</a>';
        }
        
    ?>
    </body>
</html>