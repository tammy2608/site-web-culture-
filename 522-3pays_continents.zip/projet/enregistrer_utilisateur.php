<?php require_once("connexion_base.php"); ?>

<!DOCTYPE html>

<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajout membre</title>
    <link rel="stylesheet" href="css/connexion.css">
</head>
<body>
    <?php
        if (!empty($_POST['pseudo']) and !empty($_POST['motdepasse']) and !empty($_POST['email']) and !empty($_POST['prenom']) and !empty($_POST['nom']))
        {
            $pseudo = $_POST['pseudo'];
            $motdepasse = $_POST['motdepasse'];
            $email= $_POST['email'];
            $prenom = $_POST['prenom'];
            $nom = $_POST['nom'];
            $motdepasse_crypte = password_hash($motdepasse, PASSWORD_DEFAULT);

            date_default_timezone_set("Europe/Paris");
            $date = date("Y-m-d H:i:s");

            // exécuter une requete MySQL de type INSERT
            $requete="INSERT INTO projet_utilisateur(pseudo, motdepasse, nom, prenom, email, datecreation) VALUES ( ?, ?, ?, ?, ?, ?)";
            $reponse=$pdo->prepare($requete);
            $reponse->execute(array($pseudo, $motdepasse_crypte, $nom, $prenom, $email, $date));

            echo "<h2>Votre compte a été créé avec succcès</h2>";
        }
        else
        {
            if (empty($_POST['pseudo']))
            {
            echo "<p>Veuillez renseigner le pseudo</p>";
            }
            
            if (empty($_POST['motdepasse']))
            {
            echo "<p>Veuillez renseigner le mot de passe</p>";
            }
            
            if (empty($_POST['email']))
            {
            echo "<p>Veuillez renseigner l'email</p>";
            }

            if (empty($_POST['prenom']))
            {
            echo "<p>Veuillez renseigner le prenom</p>";
            }
            
            if (empty($_POST['nom']))
            {
            echo "<p>Veuillez renseigner le nom</p>";
            }
    ?>
            <a href="connexion.php">Retour au formulaire</a>

        <?php
        }

        echo "<a href='accueil.php'>Retour à l'accueil</a>"
        ?>

</body>
</html>
